const mail = require('./mail')

module.exports = {
    mail
}